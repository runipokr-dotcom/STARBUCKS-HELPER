GitHub 저장소 루트에 index.html, coupon.html, price.html, calculate.html 파일을 업로드하세요.
